from django.urls import path 
from . import views
from .views import booking_view, create_checkout_session
from django.conf.urls.static import static
from django.conf import settings

STATIC_ROOT = "booking\static"
urlpatterns = [
    path('', views.index, name='index'),
    path('booking', views.booking, name='booking'),
    path('booking-submit', views.bookingSubmit, name='bookingSubmit'),
    path('user-panel', views.userPanel, name='userPanel'),
    path('user-update/<int:id>', views.userUpdate, name='userUpdate'),
    path('user-update-submit/<int:id>', views.userUpdateSubmit, name='userUpdateSubmit'),
    path('staff-panel', views.staffPanel, name='staffPanel'),
    path('create-checkout-session/', create_checkout_session, name='create_checkout_session'),
    path('booking/', booking_view, name='booking2'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)